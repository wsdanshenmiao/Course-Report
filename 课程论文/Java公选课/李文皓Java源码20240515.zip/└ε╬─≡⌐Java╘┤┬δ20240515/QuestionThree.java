import java.util.*;

public class QuestionThree {
	public static void main(String[] args) {
		Random random = new Random();
		int array[][] = new int[5][5];
		int sum = 0;
		int rowPos = 0,columnPos = 0, max = 0;
		for(int i = 0; i < array.length; ++i) {
			for(int j = 0; j < array[i].length; ++j) {
				array[i][j] = random.nextInt(100);
				System.out.print(array[i][j] + "\t");
				
				// 求最外圈总和
				if(i == 0 || j == 0 || 
						i == array[i].length - 1 || j == array[i].length - 1) {
					sum += array[i][j];
				}

				// 求主对角线最大值
				if(i == 0 && j == 0) {
					max = array[i][j];
				}
				if(i == j && max < array[i][j]) {
					max = array[i][j];
					rowPos = i;
					columnPos = j;
				}
			}
			System.out.println();
		}
		System.out.println("最外圈总和：" + sum);
		System.out.println("主对角线上最大值为第" + (rowPos + 1) + "行，"
				+ "第" + (columnPos + 1) + "列的" + array[rowPos][columnPos]);
		
	}
}
