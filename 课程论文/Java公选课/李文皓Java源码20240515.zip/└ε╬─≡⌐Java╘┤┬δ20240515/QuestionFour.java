
abstract class Employee
{
	Employee(String name, int birthDay[], long number)
	{
		m_Name = name;
		m_BirthDay = birthDay;
		m_Number = number;
	}
	
	public String toString()
	{
		return "姓名：" + m_Name + "\t工号：" + m_Number + 
				"\t出生日期：" + m_BirthDay[0] + "年" + 
				m_BirthDay[1] + "月" + 
				m_BirthDay[2] + "日";
	}
	
	abstract int CalculateSalary(int month,int num);
	
	String m_Name = null;
	int m_BirthDay[];
	long m_Number = 0;
}

class SalariedEmployee extends Employee
{
	SalariedEmployee(String name, int birthDay[], long number) {
		super(name, birthDay, number);
	}

	int CalculateSalary(int month, int num)
	{
		int salary = 0; 
		if(m_BirthDay[1] == month) {
			salary += 100;
		}
		return salary + baseSalary;
	}
	
	int baseSalary = 8000;
}

class HourlyEmployee extends Employee
{
	HourlyEmployee(String name, int birthDay[], long number) {
		super(name, birthDay, number);
	}

	int CalculateSalary(int month, int hour)
	{
		int salary = 0; 
		if(m_BirthDay[1] == month) {
			salary += 100;
		}
		if(hour <= 160) {
			return salary + hour * 40;
		}
		else {
			return salary + 160 * hourBaseSalary + (hour - 160) * hourBaseSalary * 2;
		}
	}
	
	int hourBaseSalary = 48;
}

class CommissionEmployee extends Employee
{
	CommissionEmployee(String name, int birthDay[], long number) {
		super(name, birthDay, number);
	}

	int CalculateSalary(int month ,int count)
	{
		int salary = 0; 
		if(m_BirthDay[1] == month) {
			salary += 100;
		}
		return salary + count * saleSalary;
	}
	
	int saleSalary = 8;
}

class BasePlusCommissionEmployee extends Employee
{
	BasePlusCommissionEmployee(String name, int birthDay[], long number) {
		super(name, birthDay, number);
	}

	int CalculateSalary(int month ,int count)
	{
		int salary = 0; 
		if(m_BirthDay[1] == month) {
			salary += 100;
		}
		return salary + baseSalary + saleSalary * count;
	}
	
	int baseSalary = 4000;
	int saleSalary = 4;
}

public class QuestionFour {
	public static void main(String[] args) {
		int birthDay[][] = {
				{1997,10,3},
				{1997,8,3},
				{1997,6,3},
				{1997,4,3},
		};
		Employee employees[] = {
				new SalariedEmployee("Madoka", birthDay[0],01),
				new HourlyEmployee("Homura", birthDay[1],02),
				new CommissionEmployee("Sayaka", birthDay[2],03),
				new BasePlusCommissionEmployee("Kyouko", birthDay[3],04)
		};
		SalariedEmployee Madoka = (SalariedEmployee)employees[0];
		HourlyEmployee Homura = (HourlyEmployee)employees[1];
		CommissionEmployee Sayaka = (CommissionEmployee)employees[2];
		BasePlusCommissionEmployee Kyouko = (BasePlusCommissionEmployee)employees[3];
		
		System.out.println(Madoka + "\t工资：" + Madoka.CalculateSalary(10, 0));
		System.out.println(Homura + "\t工资：" + Homura.CalculateSalary(10, 161));
		System.out.println(Sayaka + "\t工资：" + Sayaka.CalculateSalary(10, 1010));
		System.out.println(Kyouko + "\t工资：" + Kyouko.CalculateSalary(10, 1010));
	}
}
