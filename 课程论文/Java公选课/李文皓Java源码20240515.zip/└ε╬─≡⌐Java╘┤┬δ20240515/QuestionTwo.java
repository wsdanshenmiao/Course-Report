
class Student
{
	public Student()
	{
		this(null, 0, 0);
	}
	
	public Student(String name, int age, long number)
	{
		m_Name = name;
		m_Age = age;
		m_Number = number;
	}
	
	public String toString() 
	{
		return m_Name + '\t' + m_Age + '\t' + m_Number;
	}
	
	String m_Name;
	int m_Age;
	long m_Number;
}

public class QuestionTwo {
	public static void main(String[] args) {
		Student students[] = { 
				new Student("张三",18,311800001),
				new Student("李四",25,311800002),
				new Student("王五",20,311800003),
				new Student("甲",21,311800004),
				new Student("乙",42,311800005),
				new Student("丙",16,311800006)
		};
	
		System.out.println("所有学生信息如下：");		
		for(Student student : students) {
			System.out.println(student);
		}
		
		System.out.println("\n将所有学生年龄增加一岁");
		for(Student student : students) {
			student.m_Age += 1;
			System.out.println(student.m_Age);
		}
		
		System.out.println("\n年龄大于20岁的学生有: ");
		for(Student student : students) {
			if(student.m_Age > 20) {
				System.out.print(student.m_Name + "、");
			}
		}
	}
}
