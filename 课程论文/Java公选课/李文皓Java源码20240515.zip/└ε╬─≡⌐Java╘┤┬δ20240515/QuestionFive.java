
class Person
{
	Person(String name ,int age ,String gender)
	{
		m_Name = name;
		m_Age = age;
		m_Gender = gender;
	}
	
	void Marry(Person partner)
	{
		if(m_Gender == partner.m_Gender || 
				m_Partner != null || partner.m_Partner != null) {
			return;
		}
		if(m_Gender == "男") {
			if(m_Age < 23 || partner.m_Age < 21) {
				return;
			}
		}
		else{
			if(m_Age < 21 || partner.m_Age < 23) {
				return;
			}
		}
		m_Partner = partner;
		partner.m_Partner = this;
	}
	
	public String toString()
	{
		String string = "姓名：" + m_Name + "\t年龄：" + m_Age + "\t性别：" + m_Gender;
		if(m_Partner != null) {
			string += "\t伴侣：" + m_Partner.m_Name;
		}
		return string;
	}

	String m_Name = null;
	int m_Age = 0;
	String m_Gender = null;
	Person m_Partner = null;
}

public class QuestionFive {
	public static void main(String[] args) {
		Person Madoka = new Person("Madoka", 24, "女");
		Person Homura = new Person("Homura", 24, "男");
		Person Sayaka = new Person("Sayaka", 24, "女");
		Person Kyouko = new Person("Kyouko", 24, "男");

		System.out.println(Madoka);
		System.out.println(Homura);
		
		Madoka.Marry(Sayaka);	// 同性不可
		System.out.println(Madoka);
		System.out.println(Sayaka);
		
		Madoka.Marry(Homura);
		System.out.println(Madoka);
		System.out.println(Homura);

		Madoka.Marry(Kyouko);	// 有伴侣者不可
		System.out.println(Madoka);
		System.out.println(Kyouko);
		
		Sayaka.Marry(Kyouko);
	}
}
