import javax.swing.*;

public class QuestionOne {
	
	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("请输入班级人数：");
		int n = Integer.parseInt(s);
		int score[] = new int[n]; // 动态定义数组
		int max = score[0]; // 记录最高分
		long sum = 0;
		int x1 = 0, x2 = 0, x3 = 0, x4 = 0, x5 = 0; // 统计各分数段人数的计数变量
		
		for (int i = 0; i < n; i++) {
			String str = JOptionPane.showInputDialog("第" + (i + 1) + "个成绩?");
			score[i] = Integer.parseInt(str);
		}
		
		for (int value : score) {
			switch (value/10) {
			case 0:case 1:case 2:case 3:case 4:case 5:
                x1++;
                break;
            case 6:
                x2++;
                break;
            case 7:
                x3++;
                break;
            case 8:
                x4++;
                break;
            case 9:
            case 10:
                x5++;
                break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + value);
			}
			
			if (max < value) {
				max = value;
			}
			sum += value;
		}
		

		
		for (int value:score) {
			System.out.print(value + "\t");
		}
		
		double average = sum / score.length;
		
		System.out.println();
		System.out.println("班级的最高分为：" + max);
		System.out.println("班级的平均成绩为：" + average);
		System.out.println("班级成绩的不及格人数为：" + x1);
		System.out.println("班级成绩的及格人数为：" + x2);
		System.out.println("班级成绩的中等人数为：" + x3);
		System.out.println("班级成绩的良好人数为：" + x4);
		System.out.println("班级成绩的优秀人数为：" + x5);
	}
}
